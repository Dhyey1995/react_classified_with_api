<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Member ;

class MemberController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            $validator = $request->validate([
                'name' => 'required',
                'email' => 'required',
                'password' => 'required',
                'contact' => 'required',
            ]);
            $member = new Member;
            $member->name = $request->name;
            $member->email = $request->email;
            $member->password = $request->password;
            $member->contact = $request->contact;
            if ($member->save()) {
                $this->output_response['status'] = TRUE;
                $this->output_response['message'] = 'Your account has been registrar successfully.';
            } else {
                $this->output_response['status'] = FALSE;
                $this->output_response['message'] = 'Sorry, we have to face some technical errors. Please try again later.';    
            }
        } catch (\Exception $e) {
            $this->output_response['status'] = FALSE;
            $this->output_response['message'] = 'Sorry, we have to face some technical errors. Please try again later.';
        }
        return response($this->output_response, 200)->header('Content-Type', 'application/json');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
